@ParametersAreNonnullByDefault
package org.sonar.template.java.checks;

/**
 * This package contains the custom rules
 */
import javax.annotation.ParametersAreNonnullByDefault;
